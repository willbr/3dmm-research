Instructions:
extract Patch3dmmFPS.exe and winvv.dll into your 3dmm directory (where 3dmovie.exe is located), normally C:\program files\microsoft kids\3d movie maker.
run Patch3dmmFPS.exe
If nothing goes wrong, you should see "Everything went correctly" in the Patch3dmmFPS window.
Run 3dmovie-fast instead of 3dmovie to run movies at the higher frame rate (~18 fps)

You can edit 3dmmfps.dat to change the framerate, it's just a text file.
The first line is the multiplier (based on 3dmm's default speed, about ~6 fps), the second line shouldn't be messed with.
Travis Wells <patcher@3dmm2.com